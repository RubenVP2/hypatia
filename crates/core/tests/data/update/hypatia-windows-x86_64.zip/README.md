Test archive for the updater tests.
